# Bastards Blood Data Store

This repo stores RPG state as JSON plus append-only session event logs.
Edit via pull requests only. CI validates schemas.

## Layout
```
schemas/
data/
  characters/
  sessions/
  campaigns/
scripts/
.github/workflows/
```
